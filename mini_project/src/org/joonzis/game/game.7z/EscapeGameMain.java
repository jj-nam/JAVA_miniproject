package org.joonzis.game;

public class EscapeGameMain {
	public static void main(String[] args) {
		Room game = new Room();
		game.start();
		game.run();
	}
}